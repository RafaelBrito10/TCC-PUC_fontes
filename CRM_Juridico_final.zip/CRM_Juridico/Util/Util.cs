﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using CRM_Juridico.Models;

namespace CRM_Juridico.Util
{
    public class Util : ValidationAttribute
    {

        //private readonly Agenda dataAgenda = new Agenda();

        //public override bool IsValid(object value)
        //{
        //    string data = (string)value
        //    int dataResult = DateTime.Compare(DateTime.Today, DateTime.Parse((string)value));

        //    //int dataResult = DateTime.Compare(DateTime.Parse(dataInc), DateTime.Parse(dataFim));
        //    //int dataIncResult = DateTime.Compare(DateTime.Today, DateTime.Parse(dataInc));
        //    //int dataFimResult = DateTime.Compare(DateTime.Today, DateTime.Parse(dataFim));


        //    if (dataIncResult > 0 && dataFimResult > 0)
        //    {
        //        if (dataResult < 0)
        //        {
        //            return false;
        //        }

        //    }

        //    return true;
        //}


    }

    
}
