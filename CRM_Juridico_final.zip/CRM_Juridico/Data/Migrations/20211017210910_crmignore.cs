﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CRM_Juridico.Data.Migrations
{
    public partial class crmignore : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ClienteID1",
                table: "Clientes",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Clientes_ClienteID1",
                table: "Clientes",
                column: "ClienteID1");

            migrationBuilder.AddForeignKey(
                name: "FK_Clientes_Clientes_ClienteID1",
                table: "Clientes",
                column: "ClienteID1",
                principalTable: "Clientes",
                principalColumn: "ClienteID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Clientes_Clientes_ClienteID1",
                table: "Clientes");

            migrationBuilder.DropIndex(
                name: "IX_Clientes_ClienteID1",
                table: "Clientes");

            migrationBuilder.DropColumn(
                name: "ClienteID1",
                table: "Clientes");
        }
    }
}
