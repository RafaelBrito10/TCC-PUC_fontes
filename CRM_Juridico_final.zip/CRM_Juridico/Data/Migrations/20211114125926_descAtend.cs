﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CRM_Juridico.Data.Migrations
{
    public partial class descAtend : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "DescAtendimento",
                table: "Agendas",
                type: "nvarchar(500)",
                maxLength: 500,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DescAtendimento",
                table: "Agendas");
        }
    }
}
