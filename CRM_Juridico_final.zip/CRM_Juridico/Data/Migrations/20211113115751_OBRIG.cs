﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CRM_Juridico.Data.Migrations
{
    public partial class OBRIG : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Agendas_Processos_ProcessoID",
                table: "Agendas");

            migrationBuilder.AlterColumn<int>(
                name: "ProcessoID",
                table: "Agendas",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddForeignKey(
                name: "FK_Agendas_Processos_ProcessoID",
                table: "Agendas",
                column: "ProcessoID",
                principalTable: "Processos",
                principalColumn: "ProcessoID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Agendas_Processos_ProcessoID",
                table: "Agendas");

            migrationBuilder.AlterColumn<int>(
                name: "ProcessoID",
                table: "Agendas",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Agendas_Processos_ProcessoID",
                table: "Agendas",
                column: "ProcessoID",
                principalTable: "Processos",
                principalColumn: "ProcessoID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
