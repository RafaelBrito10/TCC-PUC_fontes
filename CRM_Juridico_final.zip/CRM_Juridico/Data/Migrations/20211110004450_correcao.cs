﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CRM_Juridico.Data.Migrations
{
    public partial class correcao : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "AgendaID",
                table: "Clientes",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Clientes_AgendaID",
                table: "Clientes",
                column: "AgendaID");

            migrationBuilder.AddForeignKey(
                name: "FK_Clientes_Agendas_AgendaID",
                table: "Clientes",
                column: "AgendaID",
                principalTable: "Agendas",
                principalColumn: "AgendaID",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Clientes_Agendas_AgendaID",
                table: "Clientes");

            migrationBuilder.DropIndex(
                name: "IX_Clientes_AgendaID",
                table: "Clientes");

            migrationBuilder.DropColumn(
                name: "AgendaID",
                table: "Clientes");
        }
    }
}
