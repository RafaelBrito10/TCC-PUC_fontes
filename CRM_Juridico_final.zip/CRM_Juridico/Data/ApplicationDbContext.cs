﻿using CRM_Juridico.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace CRM_Juridico.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Advogado> Advogados { get; set; }
        public DbSet<Agenda> Agendas { get; set; }
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Processo> Processos { get; set; } 

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Advogado>().ToTable("Advogados");
            builder.Entity<Agenda>().ToTable("Agendas");
            builder.Entity<Cliente>().ToTable("Clientes");
            builder.Entity<Processo>().ToTable("Processos");

            builder.Entity<Agenda>().
                HasOne(p => p.Advogado).
                WithMany(q => q.Agendas).
                HasForeignKey(p => p.AvogadoID);

            builder.Entity<Agenda>().
                     HasOne(p => p.Cliente).
                     WithMany(q => q.Agendas).
                     HasForeignKey(p => p.ClienteID);

            builder.Entity<Agenda>().
                     HasOne(p => p.Processo).
                     WithMany(q => q.Agendas).
                     HasForeignKey(p => p.ProcessoID);
        }




        
    }



}
