﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CRM_Juridico.Data;
using CRM_Juridico.Models;
using Microsoft.EntityFrameworkCore;

namespace CRM_Juridico.Controllers
{
    public class ClienteController : Controller
    {

        private readonly ApplicationDbContext _context;

        public ClienteController(ApplicationDbContext context)
        {
            _context = context;

        }


        // GET: ClienteController1
        public async Task<IActionResult> Index()
        {
            var clientes = await _context.Clientes.ToListAsync();
            if (clientes == null)
            {
                return View("Registros não encontrados");
            }
            else
            {
                return View(clientes);
            }
        }


        // GET: ClienteController1/Details/5
        public async Task<IActionResult> Exibir(int? clienteId)
        {
            if (clienteId == null)
            {
                return NotFound();
            }
            var cliente = await _context.Clientes.FirstOrDefaultAsync(m => m.ClienteID == clienteId);
            if (cliente == null)
            {
                return NotFound();
            }
            return View(cliente);
        }

        // GET: ClienteController1/Create
        public async Task<IActionResult> AddOuEditar(int? clienteId)
        {
            ViewBag.PageName = clienteId == null ? "Adicionar Cliente" : "Editar Cliente";
            ViewBag.IsEdit = clienteId == null ? false : true;
            if (clienteId == null)
            {
                return View();
            }
            else
            {
                var cliente = await _context.Clientes.FindAsync(clienteId);

                if (cliente == null)
                {
                    return NotFound();
                }
                return View(cliente);
            }
        }

        //AddOrEdit Post Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOuEditar(int clienteID, [Bind("ClienteID,Nome,Endereco,Municipio,Estado,Cep,Cgc,Rg,Data_nasc,Tipo_pessoa,DDD,Telefone,DDD2,Celular,Email")]
Cliente clienteData)
        {
            bool IsClienteExist = false;

            Cliente cliente = await _context.Clientes.FindAsync(clienteID);

            if (cliente != null)
            {
                IsClienteExist = true;
            }
            else
            {
                cliente = new Cliente();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    cliente.Nome = clienteData.Nome;
                    cliente.Endereco = clienteData.Endereco;
                    cliente.Municipio = clienteData.Municipio;
                    cliente.Estado = clienteData.Estado;
                    cliente.Cep = clienteData.Cep;
                    cliente.Cgc = clienteData.Cgc;
                    cliente.Rg = clienteData.Rg;
                    cliente.Data_nasc = clienteData.Data_nasc;
                    cliente.Tipo_pessoa = clienteData.Tipo_pessoa;
                    cliente.DDD = clienteData.DDD;
                    cliente.Telefone = clienteData.Telefone;
                    cliente.DDD2 = clienteData.DDD2;
                    cliente.Celular = clienteData.Celular;
                    cliente.Email = clienteData.Email;

                    if (IsClienteExist)
                    {
                        _context.Update(cliente);
                    }
                    else
                    {
                        if (await _context.Clientes.AnyAsync(x => x.Cgc == clienteData.Cgc))
                        {
                            ModelState.Clear();
                            TempData["erro"] = "Já existe um usuário com o mesmo CPF!";
                            return View();
                        }
                        if (await _context.Clientes.AnyAsync(x => x.Rg == clienteData.Rg))
                        {
                            ModelState.Clear();
                            TempData["erro"] = "Já existe um usuário com o mesmo RG!";
                            return View();
                        }

                        _context.Add(cliente);
                    }
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(clienteData);
        }


        // GET: ClienteController1/Delete/5 
        public async Task<IActionResult> Excluir(int? clienteId)
        {
            if (clienteId == null)
            {
                return NotFound();
            }
            var cliente = await _context.Clientes.FirstOrDefaultAsync(m => m.ClienteID == clienteId);

            return View(cliente);
        }

        // POST: ClienteController1/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Excluir(int clienteId)
        {
            var cliente = await _context.Clientes.FindAsync(clienteId);
            if(cliente == null)
            {
                return RedirectToAction(nameof(Index));
            }
            try
            {
                _context.Clientes.Remove(cliente);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));

            }
            catch (DbUpdateException)
            {

                TempData["mensagemErro"] = "O registro selecionado já possui relacionemato, favor verificar com administrador.";
                return RedirectToAction(nameof(Excluir), new { clienteId = clienteId, saveChangesError = true });
            }
                        

        }
        public ActionResult ValidarCgcUnico(string Cgc)
        {
            var cgcDisponivel = _context.Clientes.Any(u => u.Cgc == Cgc);
            return Json(cgcDisponivel);
        }

    }
}
