﻿using CRM_Juridico.Data;
using CRM_Juridico.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRM_Juridico.Controllers
{
    public class ProcessoController : Controller
    {
        private readonly ApplicationDbContext _context;
        
        public ProcessoController(ApplicationDbContext context)
        {
            _context = context;

        }
        // GET: ProcessoController
        public async Task<IActionResult> Index()
        {
            var processos = await _context.Processos.ToListAsync();
            if (processos == null)
            {
                return View("Registros não encontrados");
            }
            else
            {
                return View(processos);
            }
        }

        // GET: ProcessoController/Details/5
        public async Task<IActionResult> Exibir(int? processoId)
        {
            if (processoId == null)
            {
                return NotFound();
            }
            var processo = await _context.Processos.FirstOrDefaultAsync(m => m.ProcessoID == processoId);
            if (processo == null)
            {
                return NotFound();
            }
            return View(processo);
        }

        // GET: ProcessoController/Create
        public async Task<IActionResult> AddOuEditar(int? processoId)
        {
            ViewBag.PageName = processoId == null ? "Adicionar Processo" : "Editar Processo";
            ViewBag.IsEdit = processoId == null ? false : true;

            ViewData["ClienteID"] = new SelectList(_context.Clientes.ToList(), "ClienteID", "Nome");
            ViewData["AdvogadoID"] = new SelectList(_context.Advogados.ToList(), "AdvogadoID", "Nome");


            if (processoId == null)
            {
                return View();
            }
            else
            {
                var processo = await _context.Processos.FindAsync(processoId);

                if (processo == null)
                {
                    return NotFound();
                }
                return View(processo);
            }
        }
        //AddOrEdit Post Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOuEditar(int processoID, [Bind("ProcessoID,CodProcesso,Autor,Reu,Origem,Comarca,Estado,TipoProcesso,DataInicial,Titulo,Assunto,AdvogadoID,ClienteID")]
 Processo processoData)
        {
            bool IsProcessoExist = false;

            Processo processo = await _context.Processos.FindAsync(processoID);

            ViewData["ClienteID"] = new SelectList(_context.Clientes, "ClienteID", "Nome", processoData.ClienteID);
            ViewData["AdvogadoID"] = new SelectList(_context.Advogados, "AdvogadoID", "Nome", processoData.AdvogadoID);

            if (processo != null)
            {
                IsProcessoExist = true;
            }
            else
            {
                processo = new Processo();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    processo.CodProcesso = processoData.CodProcesso;
                    processo.Autor = processoData.Autor;
                    processo.Reu = processoData.Reu;
                    processo.Origem = processoData.Origem;
                    processo.Comarca = processoData.Comarca;
                    processo.Estado = processoData.Estado;
                    processo.TipoProcesso = processoData.TipoProcesso;
                    processo.DataInicial = processoData.DataInicial;
                    processo.Titulo = processoData.Titulo;
                    processo.Assunto = processoData.Assunto;
                    processo.AdvogadoID = processoData.AdvogadoID;
                    processo.ClienteID = processoData.ClienteID;

                    if (IsProcessoExist)
                    {                      
                        
                        _context.Update(processo);
                    }
                    else
                    {
                        if (await _context.Processos.AnyAsync(x => x.CodProcesso == processoData.CodProcesso))
                        {
                            ModelState.Clear();
                            TempData["erro"] = "Processo já Cadastrado!";
                            return View();
                        }
                        _context.Add(processo);
                    }
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(processoData);
        }

        // GET: ProcessoController/Delete/5
        public async Task<IActionResult> Excluir(int? processoID)
        {


            if (processoID == null)
            {
                return NotFound();
            }
            var processo = await _context.Processos.FirstOrDefaultAsync(m => m.ProcessoID == processoID);

            return View(processo);
        }

        // POST: ClienteController1/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Excluir(int processoID)
        {
            var processo = await _context.Processos.FindAsync(processoID);
            if (processo == null)
            {
                return RedirectToAction(nameof(Index));
            }
            try
            {
                _context.Processos.Remove(processo);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));

            }
            catch (DbUpdateException)
            {

                TempData["mensagemErro"] = "O registro selecionado já possui relacionemato, favor verificar com administrador.";
                return RedirectToAction(nameof(Excluir), new { processoID = processoID, saveChangesError = true });
            }

        }
    }
}
