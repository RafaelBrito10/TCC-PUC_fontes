﻿using CRM_Juridico.Data;
using CRM_Juridico.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace CRM_Juridico.Controllers
{
    [Authorize]
    public class AgendaController : Controller
    {
        private readonly ApplicationDbContext _context;
        Util.Util util = new Util.Util();

        public AgendaController(ApplicationDbContext context)
        {
            _context = context;

        }

        // GET: AgendaController1
        public async Task<IActionResult> Index(string pesquisa)
        {
            var agendas = await _context.Agendas.Include(a => a.Cliente).ToListAsync();

            if (!String.IsNullOrEmpty(pesquisa))
            {
                agendas = (List<Agenda>)agendas.Where(s => s.TipoAgenda!.Contains(pesquisa));
            }

            if (agendas == null)
            {
                return View("Registros não encontrados");
            }
            else
            {
                return View(agendas);
            }
        }
        
        // GET: AgendaController1/Details/5
        public async Task<IActionResult> Exibir(int? agendaId)
        {
            if (agendaId == null)
            {
                return NotFound();
            }
            var agenda = await _context.Agendas.FirstOrDefaultAsync(m => m.AgendaID == agendaId);
            if (agenda == null)
            {
                return NotFound();
            }
            return View(agenda);
        }

        // GET: AgendaController1/Create
        public async Task<IActionResult> AddOuEditar(int? agendaId)
        {
            //var lst = new List<string>
            //{
            //    "aberto","fechado","cancelado"
            //};

            ViewBag.PageName = agendaId == null ? "Adicionar Agendamento" : "Editar Agendamento";
            ViewBag.IsEdit = agendaId == null ? false : true;
            //ViewBag.Status = new SelectList(lst);

            ViewData["ClienteID"] = new SelectList(_context.Clientes.ToList(), "ClienteID", "Nome");
            ViewData["AdvogadoID"] = new SelectList(_context.Advogados.ToList(), "AdvogadoID", "Nome");

            if (agendaId == null)
            {
                return View();
            }
            else
            {
                var agenda = await _context.Agendas.FindAsync(agendaId);

                if (agenda == null)
                {
                    return NotFound();
                }
                return View(agenda);
            }
        }

        //AddOrEdit Post Method
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOuEditar(int agendaID, [Bind("AgendeID,TipoAgenda,DataIncial,DataFinal,ClienteID,AvogadoID,ProcessoID,Titulo,Assunto")]
Agenda agendaData)
        {
            
            bool IsAgendaExist = false;
            

            Agenda agenda = await _context.Agendas.FindAsync(agendaID);

            ViewData["ClienteID"] = new SelectList(_context.Clientes, "ClienteID", "Nome", agendaData.ClienteID);
            ViewData["AdvogadoID"] = new SelectList(_context.Advogados, "AdvogadoID", "Nome", agendaData.AvogadoID);
           

            if (agenda != null)
            {
                IsAgendaExist = true;
            }
            else
            {
                agenda = new Agenda();
            }

            if (ModelState.IsValid)
            {
                try
                {                    

                    agenda.TipoAgenda = agendaData.TipoAgenda;
                    agenda.DataIncial = agendaData.DataIncial;
                    agenda.DataFinal = agendaData.DataFinal;
                    agenda.ClienteID = agendaData.ClienteID;
                    agenda.AvogadoID = agendaData.AvogadoID;
                    agenda.ProcessoID = agendaData.ProcessoID;
                    agenda.Titulo = agendaData.Titulo;
                    agenda.Assunto = agendaData.Assunto;


                    if (IsAgendaExist)
                    {
                        if (ValidaData(agendaData.DataIncial, agendaData.DataFinal))
                        {
                            ModelState.Clear();
                            TempData["erro"] = "Agendamento não valido!";
                            return RedirectToAction(nameof(AddOuEditar), new { agendaID = agendaID, saveChangesError = true });
                        }

                        _context.Update(agenda);                               
                         
                     }
                    else
                    {

                        if (ValidaData(agendaData.DataIncial,agendaData.DataFinal))
                        {
                            ModelState.Clear();
                            TempData["erro"] = "Agendamento não valido!";
                            return RedirectToAction(nameof(AddOuEditar), new { agendaID = agendaID, saveChangesError = true });
                        }

                        agenda.Status = "1";
                       _context.Add(agenda);                     
                     
                    }
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(agendaData);
        }
        // GET: AgendaController/Atendimento
        [Authorize(Roles = "Advogado,Administrador")]
        public async Task<IActionResult> Atendimento(int? agendaId)
        {
            //var lst = new List<string>
            //{
            //    "aberto","fechado","cancelado"
            //};

            ViewBag.PageName = agendaId == null ? "Adicionar Agendamento" : "Editar Agendamento";
            ViewBag.IsEdit = agendaId == null ? false : true;
            //ViewBag.Status = new SelectList(lst);

            ViewData["ClienteID"] = new SelectList(_context.Clientes.ToList(), "ClienteID", "Nome");
            ViewData["AdvogadoID"] = new SelectList(_context.Advogados.ToList(), "AdvogadoID", "Nome");

            if (agendaId == null)
            {
                return View();
            }
            else
            {
                var agenda = await _context.Agendas.FindAsync(agendaId);

                if (agenda == null)
                {
                    return NotFound();
                }
                return View(agenda);
            }
        }

        //AddOrEdit Post Method
        [Authorize(Roles = "Advogado,Administrador")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Atendimento(int agendaID, [Bind("AgendeID,TipoAgenda,DataIncial,DataFinal,ClienteID,AvogadoID,ProcessoID,Titulo,Assunto")]
Agenda agendaData)
        {

            bool IsAgendaExist = false;


            Agenda agenda = await _context.Agendas.FindAsync(agendaID);

            ViewData["ClienteID"] = new SelectList(_context.Clientes, "ClienteID", "Nome", agendaData.ClienteID);
            ViewData["AdvogadoID"] = new SelectList(_context.Advogados, "AdvogadoID", "Nome", agendaData.AvogadoID);


            if (agenda != null)
            {
                IsAgendaExist = true;
            }
            else
            {
                agenda = new Agenda();
            }

            if (ModelState.IsValid)
            {
                try
                {                    
                    agenda.Status = "2";


                    if (IsAgendaExist)
                    {
                     _context.Update(agenda);

                    }
                    
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(agendaData);
        }
        [Authorize(Roles = "Analista,Administrador")]
        // GET: AgendaController1/Delete/5
        public async Task<IActionResult> Excluir(int? agendaId)
        {
            if (agendaId == null)
            {
                return NotFound();
            }
            var agenda = await _context.Agendas.FirstOrDefaultAsync(m => m.AgendaID == agendaId);

            return View(agenda);
        }

        // POST: ClienteController1/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Excluir(int agendaId)
        {
            try
            {
                var agenda = await _context.Agendas.FindAsync(agendaId);
                _context.Agendas.Remove(agenda);
                await _context.SaveChangesAsync();

                
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("","O Registro já possui relacionamento.");
            }
            return RedirectToAction(nameof(Index));


        }
        public bool ValidaData(string dataInc, string dataFim)
        {

            int dataResult = DateTime.Compare(DateTime.Parse(dataInc), DateTime.Parse(dataFim));
            int dataIncResult = DateTime.Compare(DateTime.Today, DateTime.Parse(dataInc));
            int dataFimResult = DateTime.Compare(DateTime.Today, DateTime.Parse(dataFim));


            if (dataIncResult > 0 && dataFimResult > 0)
            {
                if (dataResult < 0)
                {
                    return true;
                }

            }

            return false;
        }

    }

}
