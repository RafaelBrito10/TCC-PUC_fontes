﻿using CRM_Juridico.Data;
using CRM_Juridico.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRM_Juridico.Controllers
{
    [Authorize(Roles = "Analista,Administrador")]
    public class AdvogadoController : Controller
    {
        private readonly ApplicationDbContext _context;
        public AdvogadoController(ApplicationDbContext context)
        {
            _context = context;

        }

        // GET: AdvogadoController
        public async Task<IActionResult> Index()
        {
            var advogados = await _context.Advogados.ToListAsync();
            if (advogados == null)
            {
                return View("Registros não encontrados");
            }
            else
            {
                return View(advogados);
            }
        }

        // GET: AdvogadoController/Details/5
        public async Task<IActionResult> Exibir(int? advogadoId)
        {
            if (advogadoId == null)
            {
                return NotFound();
            }
            var advogado = await _context.Advogados.FirstOrDefaultAsync(m => m.AdvogadoID == advogadoId);
            if (advogado == null)
            {
                return NotFound();
            }
            return View(advogado);
        }

        // GET: AdvogadoController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: AdvogadoController/Create
        public async Task<IActionResult> AddOuEditar(int? advogadoId)
        {
            ViewBag.PageName = advogadoId == null ? "Adicionar Advogado" : "Editar Advogado";
            ViewBag.IsEdit = advogadoId == null ? false : true;
            if (advogadoId == null)
            {
                return View();
            }
            else
            {
                var advogado = await _context.Advogados.FindAsync(advogadoId);

                if (advogado == null)
                {
                    return NotFound();
                }
                return View(advogado);
            }
        }

        //AddOrEdit Post Method
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOuEditar(int advogadoID, [Bind("AdvogadoID,Nome,Endereco,Municipio,Estado,Cep,Cpf,Rg,Data_nasc,OAB,DDD,Telefone,DDD2,Celular,Email")]
 Advogado advogadoData)
        {
            bool IsAdvogadoExist = false;

            Advogado advogado = await _context.Advogados.FindAsync(advogadoID);

            if (advogado != null)
            {
                IsAdvogadoExist = true;
            }
            else
            {
                advogado = new Advogado();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    advogado.Nome = advogadoData.Nome;
                    advogado.Endereco = advogadoData.Endereco;
                    advogado.Municipio = advogadoData.Municipio;
                    advogado.Estado = advogadoData.Estado;
                    advogado.Cep = advogadoData.Cep;
                    advogado.Cpf = advogadoData.Cpf;
                    advogado.Rg = advogadoData.Rg;
                    advogado.Data_nasc = advogadoData.Data_nasc;
                    advogado.OAB = advogadoData.OAB;
                    advogado.DDD = advogadoData.DDD;
                    advogado.Telefone = advogadoData.Telefone;
                    advogado.DDD2 = advogadoData.DDD2;
                    advogado.Celular = advogadoData.Celular;
                    advogado.Email = advogadoData.Email;

                    if (IsAdvogadoExist)
                    {
                        if (await _context.Advogados.AnyAsync(x => x.Cpf == advogadoData.Cpf))
                        {
                            ModelState.Clear();
                            TempData["erro"] = "Já existe um usuário com o mesmo CPF!";
                            return View();
                        }
                        if (await _context.Advogados.AnyAsync(x => x.Rg == advogadoData.Rg))
                        {
                            ModelState.Clear();
                            TempData["erro"] = "Já existe um usuário com o mesmo RG!";
                            return View();
                        }
                        if (await _context.Advogados.AnyAsync(x => x.OAB == advogadoData.OAB))
                        {
                            ModelState.Clear();
                            TempData["erro"] = "Já existe um usuário com o mesmo OAB!";
                            return View();
                        }
                        _context.Update(advogado);
                    }
                    else
                    {
                        _context.Add(advogado);
                    }
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(advogadoData);
        }

        // GET: AdvogadoController/Delete/5
        public async Task<IActionResult> Excluir(int? advogadoID)
        {


            if (advogadoID == null)
            {
                return NotFound();
            }
            var advogado = await _context.Advogados.FirstOrDefaultAsync(m => m.AdvogadoID == advogadoID);

            return View(advogado);
        }

        // POST: ClienteController1/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Excluir(int advogadoID)
        {
            var advogado = await _context.Advogados.FindAsync(advogadoID);
            if (advogado == null)
            {
                return RedirectToAction(nameof(Index));
            }
            try
            {
                _context.Advogados.Remove(advogado);
                await _context.SaveChangesAsync();

                return RedirectToAction(nameof(Index));

            }
            catch (DbUpdateException)
            {

                TempData["mensagemErro"] = "O registro selecionado já possui relacionemato, favor verificar com administrador.";
                return RedirectToAction(nameof(Excluir), new { advogadoID = advogadoID, saveChangesError = true });
            }
            //var advogado = await _context.Clientes.FindAsync(advogadoID);
            //_context.Clientes.Remove(advogado);
            //await _context.SaveChangesAsync();

            //return RedirectToAction(nameof(Index));
        }
    }
}
