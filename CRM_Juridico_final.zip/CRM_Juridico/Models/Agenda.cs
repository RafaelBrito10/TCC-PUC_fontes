﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc;

namespace CRM_Juridico.Models
{
    public class Agenda
    { 
        
        [Key]
        [Display(Name = "Código")]
        public int AgendaID { get; set; }

        
        [Display(Name = "Tipo de Atendimento")]
        public string TipoAgenda { get; set; }

       
        [DataType(DataType.DateTime)]
        [Display(Name = "Data Inicial")]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd HH:mm:ss}", ApplyFormatInEditMode = true)]
        public string DataIncial { get; set; }

        
        [DataType(DataType.DateTime)]

        [Display(Name = "Data Final")]
        [DisplayFormat(DataFormatString = "{0:yyyy/MM/dd HH:mm:ss}", ApplyFormatInEditMode = true)]
  
        public string DataFinal { get; set; }

       
        [Display(Name = "Cliente")]
        public int? ClienteID { get; set; }

       
        [Display(Name = "Advogado")]
        public int? AvogadoID { get; set; }

      
        [Display(Name = "Processo")]
        public int? ProcessoID { get; set; }

      
        [StringLength(100)]
        public string Titulo { get; set; }

       
        [MaxLength(500)]
        public string Assunto { get; set; }

        [MaxLength(500)]
        [Display(Name = "Descrição do Atendimento")]
        public string DescAtendimento { get; set; }


        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime EnrollmentDate { get; set; }

        [Display(Name = "Situação")]
        [StringLength(1)]
        public string Status { get; set; }

        public Advogado Advogado { get; set; }
        public Cliente Cliente { get; set; }
        public Processo Processo { get; set; }



      

        //public virtual ICollection<Cliente> Clientes { get; set; }
    }
}
