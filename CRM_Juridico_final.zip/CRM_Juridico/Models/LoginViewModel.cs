﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CRM_Juridico.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "O Usuario é obrigatório")]
        //[EmailAddress(ErrorMessage = "Email inválido")]
        [Display(Name = "Usuário")]
        public string UserName { get; set; }

        [Required(ErrorMessage = "A senha é obrigatória")]
        [DataType(DataType.Password)]
        [Display(Name = "Senha")]
        public string Password { get; set; }


        [Display(Name = "Lembrar-me")]
        public bool RememberMe { get; set; }
    }
}
