﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CRM_Juridico.Models
{
    public class UserRoleViewModel
    {
        [Display(Name = "Código")]
        public string UserId { get; set; }
        [Display(Name = "Usuário")]
        public string UserName { get; set; }
        public bool IsSelected { get; set; }
    }
}
