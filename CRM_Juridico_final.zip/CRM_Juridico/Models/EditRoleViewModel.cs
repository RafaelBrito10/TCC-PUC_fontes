﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CRM_Juridico.Models
{
    public class EditRoleViewModel
    {
        public EditRoleViewModel()
        {
            Users = new List<string>();
        }
        [Display(Name = "Código")]
        public string Id { get; set; }
        [Required(ErrorMessage = "O nome do perfil é obrigatório")]
        [Display(Name = "Perfil")]
        public string RoleName { get; set; }
        public List<string> Users { get; set; }
    }
}

