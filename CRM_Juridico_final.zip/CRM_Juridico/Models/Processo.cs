﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CRM_Juridico.Models
{
    public class Processo
    {
        
        [Key]
        [Display(Name = "Código")]
        public int ProcessoID { get; set; }

        [Required]
        [Display(Name = "Número do Processo")]
        public string CodProcesso { get; set; }

        [Required]
        [StringLength(100)]
        public string Autor { get; set; }
        
        [Required]
        [StringLength(100)]
        [Display(Name = "Réu")]
        public string Reu { get; set; }
        
        [Required]
        public string Origem { get; set; }
       
        [Required]
        [Display(Name = "Cômarca")]
        public string Comarca { get; set; }

        [Required]
        [StringLength(2)]
        public string Estado { get; set; }

        [Required]
        [Display(Name = "Tipo do Processo")]
        public string TipoProcesso { get; set; }
        
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public string DataInicial { get; set; }

        [Required]
        public string Titulo { get; set; }
        
        [Required]
        public string Assunto { get; set; }

        [Display(Name = "Advogado")]
        public int? AdvogadoID { get; set; }

        [Display(Name = "Cliente")]
        public int? ClienteID { get; set; }
        

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime EnrollmentDate { get; set; }      

        public Advogado Advogado { get; set; }
        public Cliente Cliente { get; set; }

        public virtual ICollection<Agenda> Agendas { get; set; }
        /*
         numero
         autor
         reu
         juizo de origem ()
         comarca(região em que o processo vai tramitar)
         data de distribuição( data inicial)
         tipo do processo(civil, trabalhista, criminal)        
         titulo
         assunto( conteudo do processo)
         estado

         sistema GERPRO

         */

    }
}
