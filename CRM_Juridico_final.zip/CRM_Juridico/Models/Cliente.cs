﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;

namespace CRM_Juridico.Models
{
    public class Cliente
    {
        [Key]
        [Display(Name = "Código")]
        public int ClienteID { get; set; }
        
        [Required]
        [StringLength(100)]
        public string Nome { get; set; }

        [Required]
        [StringLength(100)]
        public string Endereco { get; set; }

       
        [StringLength(6)]
        [Display(Name = "Número")]
        public string Numero { get; set; }

       
        [StringLength(200)]
        public string Complemento { get; set; }

        [Required]
        [StringLength(100)]
        public string Municipio { get; set; }

        [Required]
        [StringLength(2)]
        public string Estado { get; set; }   


        [Required]
        [StringLength(9)]
        public string Cep { get; set; }

        [Required]
        [Display(Name = "CPF/CNPJ")]
        public string Cgc { get; set; }

        [Required]
        [StringLength(9)]
        [Display(Name = "RG")]
        public string Rg {get; set; }

        [Required]
        [Display(Name = "Data de Nascimento")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public string Data_nasc { get; set; }

        [Required]
        [Display(Name = "Tipo Pessoa")]
        [StringLength(1)]
        public string Tipo_pessoa { get; set; }

        //public IEnumerable<string> Tipo_pessoa { get; set; }
        //public List<SelectListItem> tipoPessoa { get; } = new List<SelectListItem>
        //{
        //    new SelectListItem { Value = "1", Text = "Física" },
        //    new SelectListItem { Value = "2", Text = "Jurídica" }

        //};

        [Required]
        [StringLength(2)]
        public string DDD { get; set; }

        [Required]
        [StringLength(9)]
        public string Telefone { get; set; }

        [StringLength(2)]
        public string DDD2 { get; set; }

        [StringLength(9)]
        public string Celular { get; set; }

        [RegularExpression(@"^([0-9a-zA-Z]([\+\-_\.][0-9a-zA-Z]+)*)+@(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]*\.)+[a-zA-Z0-9]{2,3})$", ErrorMessage = "Informe um email válido.")]
        public string Email { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime EnrollmentDate{ get; set; }        


        public virtual ICollection<Agenda> Agendas { get; set; }

        public virtual ICollection<Cliente> Clientes { get; set; }


 




    }
}
