﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CRM_Juridico.Models
{
    public class Advogado
    {
        [Key]
        [Display(Name = "Código")]
        public int AdvogadoID { get; set; }

        [Required]
        [StringLength(100)]
        public string Nome { get; set; }

        [Required]
        [StringLength(200)]
        public string Endereco { get; set; }

        
        [StringLength(6)]
        public string Numero { get; set; }

       
        [StringLength(200)]
        public string Complemento { get; set; }

        [Required]
        [StringLength(100)]
        public string Municipio { get; set; }

        [Required]
        [StringLength(2)]
        public string Estado { get; set; }

        [Required]
        [StringLength(9)]
        public string Cep { get; set; }

        [Required]
        [StringLength(11)]
        [Display(Name = "CPF")]
        public string Cpf { get; set; }

        [Required]
        [StringLength(9)]
        [Display(Name = "RG")]
        public string Rg { get; set; }

        [Required]
        [StringLength(10)]
        public string OAB { get; set; }

        [Required]
        [Display(Name = "Data de Nascimento")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public string Data_nasc { get; set; }

        [Required]
        [StringLength(2)]
        public string DDD { get; set; }

        [Required]
        [StringLength(9)]
        public string Telefone { get; set; }

        
        [StringLength(2)]
        [Display(Name = "DDD")]
        public string DDD2 { get; set; }

        
        [StringLength(9)]
        public string Celular { get; set; }

       
        [StringLength(100)]
        public string Email { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime EnrollmentDate { get; set; }
        
        public virtual ICollection<Agenda> Agendas { get; set; }
    }
}
